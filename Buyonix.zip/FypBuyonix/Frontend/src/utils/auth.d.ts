// Type definitions for auth.js
export function GoogleAuth(): void;
export function checkAuthStatus(): Promise<any>;
export function logout(): void;
